-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 27, 2019 at 03:01 PM
-- Server version: 5.7.23
-- PHP Version: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reporta`
--

-- --------------------------------------------------------

--
-- Table structure for table `agency`
--

DROP TABLE IF EXISTS `agency`;
CREATE TABLE IF NOT EXISTS `agency` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `agency_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sector` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agency_sector_foreign` (`sector`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `directorate`
--

DROP TABLE IF EXISTS `directorate`;
CREATE TABLE IF NOT EXISTS `directorate` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `directorate_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `entity`
--

DROP TABLE IF EXISTS `entity`;
CREATE TABLE IF NOT EXISTS `entity` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `entity_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sector` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entity_sector_foreign` (`sector`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_03_26_212602_create_stakeholder_table', 1),
(4, '2019_03_26_212649_create_reports_table', 1),
(5, '2019_03_26_212716_create_questions_table', 1),
(6, '2019_03_26_212746_create_sectors_table', 1),
(7, '2019_03_26_212825_create_entity_table', 1),
(8, '2019_03_26_212852_create_agency_table', 1),
(9, '2019_03_26_212937_create_directorate_table', 1),
(10, '2019_03_26_213035_create_roles_table', 1),
(11, '2019_03_26_213126_create_user_roles_table', 1),
(12, '2019_03_26_214847_create_provisional_summery_table', 1),
(13, '2019_03_26_215524_create_provisional_comments_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `provisional_comments`
--

DROP TABLE IF EXISTS `provisional_comments`;
CREATE TABLE IF NOT EXISTS `provisional_comments` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `provisional_summery`
--

DROP TABLE IF EXISTS `provisional_summery`;
CREATE TABLE IF NOT EXISTS `provisional_summery` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `summery_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prov_summery` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `question_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_3` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_4` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_5` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_6` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_7` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
CREATE TABLE IF NOT EXISTS `reports` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `report_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rpeort_keyword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year_published` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_summery` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_findings` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Recommendations_AG` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Recommendations_PAC` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_by_finace` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_by_auditee` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `directorate` int(10) UNSIGNED NOT NULL,
  `questions` int(10) UNSIGNED NOT NULL,
  `provisional_summery` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_directorate_foreign` (`directorate`),
  KEY `reports_questions_foreign` (`questions`),
  KEY `reports_provisional_summery_foreign` (`provisional_summery`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `report_name`, `rpeort_keyword`, `report_password`, `year_published`, `report_summery`, `status`, `key_findings`, `Recommendations_AG`, `attachment_name`, `Recommendations_PAC`, `action_by_finace`, `action_by_auditee`, `directorate`, `questions`, `provisional_summery`, `created_at`, `updated_at`) VALUES
(1, 'water report', 'report1', 'report1', '1991', 'sdasdasadadaddadadadasdsadsadasd', 'pending', 'asdasdasdaassadasdasdsadsadsadsad', 'asdasddaasdassssssssssssssssssssssssssssssssssssssssssssadasdd', 'waterz', 'asdasdasdasdasdasddddsdasdadasdadsadsads', 'submitted', 'submitted', 1, 1, 1, '2019-03-27 07:00:00', '2019-03-27 07:00:00'),
(2, 'umeme', 'report2', 'report2', '2019', 'sdfdsfssdfsdsdfsdfdsfsdsd', 'reviewed', 'dfgfdgdgdfggdggfdgfdgfdgfd', 'dfgdfgdfgdfgdfgdfgdgdfgfgfdgfdgfd', '', '', 'reviewed', 'not yet', 2, 2, 4, '2019-03-27 07:00:00', '2019-03-27 07:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sectors`
--

DROP TABLE IF EXISTS `sectors`;
CREATE TABLE IF NOT EXISTS `sectors` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sector_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stakeholder`
--

DROP TABLE IF EXISTS `stakeholder`;
CREATE TABLE IF NOT EXISTS `stakeholder` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `stake_holder_ctgry` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `stake_holder` int(10) UNSIGNED NOT NULL,
  `role` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_stake_holder_foreign` (`stake_holder`),
  KEY `users_role_foreign` (`role`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
