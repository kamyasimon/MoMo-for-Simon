<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer_order extends Model
{
    //
}
