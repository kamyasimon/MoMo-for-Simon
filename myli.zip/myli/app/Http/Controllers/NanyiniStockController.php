<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Productlist;
use App\Productstock;
use App\Categories;
use App\Companies;

class NanyiniStockController extends Controller
{
    //
    ////////////////create company in the dash  board
public function create_company(Request $request)
    {
        ///create a company in the dash board

        $new_company_name= $request->input('new_company_name');
        $new_company_code= $request->input('new_company_code');



        
        $create_a_company= companies::create([
            
            'company_name' => $new_company_name,
            'unique_id'=> $new_company_code,
            
        ]);

         return back();

    }

/////show the stock for view 
    public function stock_edit()
    {
        //company edit on the dash board
        $products = Productlist::all();
        $stocks = Productstock::all();
        $categories = Categories::all();
        $companies = Companies::all();
        return view('nanyini.add_stock', compact('products','categories','companies','stocks'));
    }

    //////ADD A PRODUCT TO YOUR STOCK

     public function add_stock(Request $request)
    {
        ///create a company in the dash board

        

        


        $company= $request->input('company');
        $category= $request->input('category');
        $product_name= $request->input('product_name');
        $product_batch_number= $request->input('product_batch_number');
        $stock_price= $request->input('stock_price');
        $selling_price= $request->input('selling_price');
        $profit= $selling_price-$stock_price;
        $date_of_stock= $request->input('date_of_stock');
        $expiry_date= $request->input('expiry_date');
        $product_image= $request->input('product_image');
        $product_video= $request->input('product_video');
       


        
        $stock_a_product= Productstock::create([
            
            'product_name' => $product_name ,
            'batch_num' =>$product_batch_number ,
            'stock_price' => $stock_price,
            'selling_price' => $selling_price ,
            'profit' => $profit,
            'date_of_stock' => 'n/a',
            'date_sold' =>'n/a' ,
            'durability' =>'n/a' ,          
            'stock_entered_by' => '1',
            'bought_by_customer' => '1',
            'company_product' =>'1' ,
            'myli_store' => '1',
            'product_category' => '1',
            'product_image' =>'1' ,
            'product_video' =>'1' ,
            
        ]);
    
         return back();



    }

   //////////////show a single company for selected for editing
   public function company_edit_show($id)
    {
        //show one company for edit on the dash board
        $company = companies::find($id);
        $companies = companies::all();
         
        //return view('nanyini.company_edit_show', compact('company','companies'));
    } 

////////update company
    
         public function company_update(Request $request, $id)
    {
        ///create a company in the dash board

        $update_company_name= $request->input('update_company_name');
        $update_company_code= $request->input('update_company_code');



        
        $create_a_company= companies::where('id',$id)->update([
            
            'company_name' => $update_company_name,
            'unique_id'=> $update_company_code,
            
        ]);

         return back();

    }

    ///////CREATE NEW PRODUCT CATEGORY

public function add_category(Request $request)
    {
        ///create a company in the dash board

        $new_category_name= $request->input('new_category_name');
        


        
        $create_a_company= Categories::create([
            
            'category_name' => $new_category_name,
            
            
        ]);

         return back();

    }

    public function view_category()
    {
        //company edit on the dash board
       
        $categories = Categories::all();
         
        return view('nanyini.categories', compact('categories'));
    }



///////ADD NEW PRODUCT TO SYSTEM

    public function new_product(Request $request)
    {
        ///create a company in the dash board

        

        if($request->hasFile('image_file')){

        $Orig_filename = $request->image_file->getClientOriginalName();
        $Orig_fileExtension = $request->image_file->getClientOriginalExtension();
        $Original_file_name = str_replace('.'.$Orig_fileExtension,'',$Orig_filename);
        $Image_folder = $request->input('productimages');
        
         $request->image_file->storeAs('public/media/images/'.$Image_folder,$Orig_filename);


        $new_product_name= $request->input('new_product_name');
        $new_product_category= $request->input('new_product_category');
        $related_category_a= $request->input('related_category_a');
        $related_category_b= $request->input('related_category_b');
        $related_category_c= $request->input('related_category_c');
        $new_shelf_number= $request->input('new_shelf_number');
        $visibility= $request->input('visibility');
        $producer_company= $request->input('producer_company');
       //$image_file= $request->input('image_file');
        $video_link= $request->input('video_link');
        


        
        $create_a_product= Productlist::create([
            
            'product_name' => $new_product_name,
            'shelf_number'=> $new_shelf_number,
            'visibilty'=> $visibility,
            'product_image'=> $Original_file_name ,
            'product_video'=> $video_link,
            'related_category_a'=> $related_category_a,
            'related_category_b'=> $related_category_b,
            'related_category_c'=> $related_category_c,
            'company_product'=> $producer_company,
            'product_category'=> $new_product_category,
            
        ]);
    }

         return back();



    }


/////SHOW SYSTEM PRODUCT LIST
    public function show_product_list()
    {
        //company edit on the dash board
        $products = Productlist::all();
        $categories = Categories::all();
        $companies = Companies::all();
         
        return view('nanyini.product_list', compact('products','categories','companies'));
    }
   





}
