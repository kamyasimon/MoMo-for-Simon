<?php

namespace App\Http\Controllers;

use App\Advert_images;
use Illuminate\Http\Request;

class AdvertImagesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Advert_images  $advert_images
     * @return \Illuminate\Http\Response
     */
    public function show(Advert_images $advert_images)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Advert_images  $advert_images
     * @return \Illuminate\Http\Response
     */
    public function edit(Advert_images $advert_images)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Advert_images  $advert_images
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Advert_images $advert_images)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Advert_images  $advert_images
     * @return \Illuminate\Http\Response
     */
    public function destroy(Advert_images $advert_images)
    {
        //
    }
}
