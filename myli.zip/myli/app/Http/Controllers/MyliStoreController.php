<?php

namespace App\Http\Controllers;

use App\Myli_store;
use Illuminate\Http\Request;

class MyliStoreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Myli_store  $myli_store
     * @return \Illuminate\Http\Response
     */
    public function show(Myli_store $myli_store)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Myli_store  $myli_store
     * @return \Illuminate\Http\Response
     */
    public function edit(Myli_store $myli_store)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Myli_store  $myli_store
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Myli_store $myli_store)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Myli_store  $myli_store
     * @return \Illuminate\Http\Response
     */
    public function destroy(Myli_store $myli_store)
    {
        //
    }
}
