<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Companies;
use App\Myli_store;

class NanyiniController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view ('nanyini.nanyini_welcome');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    //////custom named routes
    public function useredit()
    {
        //useredit
        $user_edit = companies::all();
         
        return view('nanyini.user_edit', compact('user_edit'));
    }
    public function adminreport()
    {
        //useredit
        return view ('nanyini.adminreport');
    }
      public function stats()
    {
        //useredit
        return view ('nanyini.stats');
    }

////////////////create company in the dash  board
public function create_company(Request $request)
    {
        ///create a company in the dash board

        $new_company_name= $request->input('new_company_name');
        $new_company_code= $request->input('new_company_code');



        
        $create_a_company= companies::create([
            
            'company_name' => $new_company_name,
            'unique_id'=> $new_company_code,
            
        ]);

         return back();

    }

/////show the company for view 
    public function company_edit()
    {
        //company edit on the dash board
        $companies = companies::all();
         
        return view('nanyini.company_edit', compact('companies'));
    }

   //////////////show a single company for selected for editing
   public function company_edit_show($id)
    {
        //show one company for edit on the dash board
        $company = companies::find($id);
        $companies = companies::all();
         
        return view('nanyini.company_edit_show', compact('company','companies'));
    } 

////////update company
    
         public function company_update(Request $request, $id)
    {
        ///create a company in the dash board

        $update_company_name= $request->input('update_company_name');
        $update_company_code= $request->input('update_company_code');



        
        $create_a_company= companies::where('id',$id)->update([
            
            'company_name' => $update_company_name,
            'unique_id'=> $update_company_code,
            
        ]);

         return back();

    }


/////show the company for view 
    public function super_store()
    {
        //company edit on the dash board
        $stores = Myli_store::all();
         
        return view('nanyini.store_mgt', compact('stores'));
    }

//////create new store

      public function create_store(Request $request)
    {
        ///create a company in the dash board

        $new_store_name= $request->input('new_store_name');
        $new_store_code= $request->input('new_store_code');
        $new_store_location= $request->input('new_store_location');



        
        $create_a_store= Myli_store::create([
            
            'store_name' => $new_store_name,
            'unique_id'=> $new_store_code,
            'location'=> $new_store_location,
            
        ]);

         return back();

    }



    


}
