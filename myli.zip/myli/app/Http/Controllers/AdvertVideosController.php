<?php

namespace App\Http\Controllers;

use App\Advert_videos;
use Illuminate\Http\Request;

class AdvertVideosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Advert_videos  $advert_videos
     * @return \Illuminate\Http\Response
     */
    public function show(Advert_videos $advert_videos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Advert_videos  $advert_videos
     * @return \Illuminate\Http\Response
     */
    public function edit(Advert_videos $advert_videos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Advert_videos  $advert_videos
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Advert_videos $advert_videos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Advert_videos  $advert_videos
     * @return \Illuminate\Http\Response
     */
    public function destroy(Advert_videos $advert_videos)
    {
        //
    }
}
