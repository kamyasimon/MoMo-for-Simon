<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Report;
use App\Questions;

class ReportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $report = Report::all();
        //echo $report;
        return view('report.index', compact('report'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //showing the ID of the report selected 
        $report = Report::find($id);
        $question= Questions::find($report->questions);
        return view('report.show', compact('report','question'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    //custom methods 

    //parliamentary liaison as pal
       public function pal()
    {
        //
        $report = Report::all();
        //echo $report;
        return view('pal.index', compact('report'));
    }

///FK combining function////////
    protected function validator (array $request)
    {
        return validator::make($request,[
            'report_name' => $report_name,///the input report name
            'year_published'=>$year_published,///the input publication year

        ]);
    }


    //create report for pal
    protected $newadded;

      public function create_report(Request $request )
    {
       // $report_name  = $request->input('report_name');
        //$year_published  = $request->input('year_published');
        
  ////a function that creates the questions raw in the questions table
   $create_qn = Questions::create([

   ]);
   /////////////////////////////////
      

//////join the report id and the questions table id/////////
        $create_a_report= Report::create([
            
            'report_name' => $request['report_name'],
            'year_published'=>$request['year_published'],
            'questions'=>$create_qn->id,
        ]);

   $newadded=$create_a_report->id;


  

  // $this->create_report_info($newadded);
  // echo $newadded;

  
  
      return redirect()->route('paledit.show',[$newadded]); 

    }





}

