<?php

namespace App\Http\Controllers;

use App\Customer_order;
use Illuminate\Http\Request;

class CustomerOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Customer_order  $customer_order
     * @return \Illuminate\Http\Response
     */
    public function show(Customer_order $customer_order)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Customer_order  $customer_order
     * @return \Illuminate\Http\Response
     */
    public function edit(Customer_order $customer_order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Customer_order  $customer_order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Customer_order $customer_order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Customer_order  $customer_order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Customer_order $customer_order)
    {
        //
    }

    public function show_order()
    {
        //

        return view('purchases.shop_cart');
    }






}
