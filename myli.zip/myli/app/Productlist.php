<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Productlist extends Model
{
    //
    protected $table = 'product_list';

    protected $fillable = [
	        
            'product_name',
            'shelf_number',
            'visibilty',
           	'product_image',
            'product_video',
            'related_category_a',
            'related_category_b',
            'related_category_c',
           	'company_product',
			       'product_category',
            
    ];


     public function Productstock(){
        
        return $this->hasMany('App\Productstock','id'); 
    }
}
