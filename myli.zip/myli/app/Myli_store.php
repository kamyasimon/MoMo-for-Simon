<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Myli_store extends Model
{
    //

    protected $table = 'myli_store';

    protected $fillable = [
	        
            'store_name',
            'unique_id',
            'location',
           	
            
    ];


}
