<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Productstock extends Model
{
    //
    protected $table = 'product_stock';
     protected $fillable = [
	        'product_name',
			'batch_num',
			'stock_price',
			'selling_price',
			'profit',
			'status',
			'date_of_stock',
			'order_status',
			'date_sold',
			'durability',
			'rating',
			'visits',
			'stock_entered_by',
			'bought_by_customer',
			'company_product',
			'myli_store',
			'product_category',
			'product_image',
			'product_video',
    ];

    public function Productlist(){
        
        return $this->belongsTo('App\Productlist','product_name'); 
    }
}
