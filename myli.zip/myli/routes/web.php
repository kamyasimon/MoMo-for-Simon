<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');




//POST


//URL routes 
Route::get('pal', 'ReportsController@pal');
//Route::get('pal', 'PaleditController@update');
Route::get('create_report_info', 'ReportsController@create_report_info');

// added
Route::resource('companies', 'CompaniesController');

Route::resource('paledit', 'PaleditController');

Route::resource('pac', 'PacController');

Route::resource('fin', 'FinanceController');

Route::resource('auditee', 'AuditeeController');

Route::resource('nanyini_body', 'NanyiniController');

//named routes for Dashboard

Route::get('useredit', 'NanyiniController@useredit');


Route::get('dboard', 'NanyiniController@index');
Route::get('adminreport', 'NanyiniController@adminreport');
Route::get('stats', 'NanyiniController@stats');


//////company control////Dashboard////////
Route::post('create_company', 'NanyiniController@create_company');
Route::get('company_edit', 'NanyiniController@company_edit');
///Url route for id show
Route::get('/company_edit_show/{id}', 'NanyiniController@company_edit_show');
Route::put('/company_update/{id}', 'NanyiniController@company_update');

//////stock control////Dashboard////////
Route::post('add_stock', 'NanyiniStockController@add_stock');
Route::get('stock_edit', 'NanyiniStockController@stock_edit');
///Url route for id show
Route::get('/stock_edit_show/{id}', 'NanyiniStockController@stock_edit_show');
Route::put('/stock_update/{id}', 'NanyiniStockController@stock_update');


//////category control////Dashboard////////
Route::get('categories', 'NanyiniStockController@view_category');
Route::post('add_category', 'NanyiniStockController@add_category');

//////new Product control////Dashboard////////
Route::post('new_product', 'NanyiniStockController@new_product');
Route::get('product_list', 'NanyiniStockController@show_product_list');


//////main Store Control////Dashboard////////
Route::post('create_store', 'NanyiniController@create_store');
Route::get('super_store', 'NanyiniController@super_store');


//////customer orders////////////
Route::post('place_order', 'CustomerOrderController@place_order');
Route::get('shop_cart', 'CustomerOrderController@show_order');