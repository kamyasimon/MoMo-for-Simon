@extends('dashboard.dboard')
@section('useredit')
<h1>welcome to user edit</h1>
<div class="container">
<div class="navbar col-lg-2">
  
  <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Bootstrap Sidebar</h3>
            </div>

              <ol>
 
  @foreach($users as $user)

  <li>
    <a href="{{ url ('userdetail',$user->id) }} "> 
    {{$user->name}}
  </a>

  </li>

  @endforeach

  </ol>
        </nav>

 

 
</div>
{{--//////////////// Detail DIV /////////////--}}






<div  class="col-lg-10" style="background-color: rgb(12,56,45);color:white; ">
 
@yield ('userdetail')

</div>

</div>

@endsection


