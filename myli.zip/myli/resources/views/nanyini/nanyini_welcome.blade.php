@extends('dashboard.dboard')
@section('welcome')
<h1>welcomeDB WELCOME</h1>

@endsection
