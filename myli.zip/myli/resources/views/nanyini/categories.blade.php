
@extends('dashboard.dboard')
@section('categories')
{--//////CREATE NEW CATEGORY////--}
<div>
  
<form  action="add_category" method="post" enctype="multipart/form-data">
    {{csrf_field()}}



  <div class="form-group">
    <label > Create New Category </label>
    <input type="text" class="form-control"  placeholder="new Category name" name="new_category_name">
  </div>
    
  <div class="form-group">
    
    <button type="submit" class="btn btn-secondary">Create Category </button>
  </div>
</form>


</div>

{--//////SHOW CATEGORY////--}
<div>
  

<table>
<th><h2>Category name:  </h2></th>

@foreach( $categories as $category)


<tr>
<td>
<a href="{{-- url ('company_edit_show',$company->id)--}}"> {{ $category->category_name }}</a>

</td>
</tr>

@endforeach
 </table>

</div>


@endsection