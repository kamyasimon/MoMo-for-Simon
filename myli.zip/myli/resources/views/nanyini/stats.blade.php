@extends('dashboard.dboard')
@section('stats')
<h1>welcome to statistics</h1>

@endsection
