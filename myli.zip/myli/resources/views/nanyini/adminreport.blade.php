@extends('dashboard.dboard')
@section('adminreport')
<h1>welcome to admin reports</h1>

@endsection
