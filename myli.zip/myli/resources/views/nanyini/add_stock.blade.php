@extends('dashboard.dboard')
@section('add_stock')

<h1>You are at Product Stock Management</h2>
<div class="container" >
<div class="navbar col-md-6 " style="overflow-y: scroll;">


  <table class="table" >
  <thead style="color:brown; ">
    <tr>
      
      <th></th>

     
    </tr>
  </thead>
  <tbody >

    <form action="add_stock" method="post" enctype="multipart/form-data">
    {{csrf_field()}}

    <tr>
    <td><label for="exampleFormControlInput1"> Produce Company </label></td>
      <td>
        <select name="company" style="width: 90%">
          
         @foreach($companies as $company)
        <option value="{{$company -> id}}">{{$company -> company_name}}</option>
        @endforeach
        </select>
      </td>
      </tr>


   <tr>
      <td><label for="exampleFormControlInput1"> Category </label></td>
      <td>
      <select name="category" style="width: 90%">
          
          @foreach($categories as $category ) 
        <option value="{{$category->id}}" >{{ $category->category_name }}</option>
       @endforeach 
      </select>
    </td>
    </tr>
    <tr>
      <td><label for="exampleFormControlInput1"> Product name </label></td>
      <td>
      <select name="product_name" style="width: 90%">
          
          @foreach($products as $product ) 
        <option value="{{$product->id}}" >{{ $product->product_name}}</option>
       @endforeach 
      </select>
    </td>
    </tr>
      <tr>
      <td><label for="exampleFormControlInput1"> Enter batch Code </label></td>
   <td> <input type="text" class="form-control" placeholder="product batch number" name="product_batch_number"> </td></tr>

   <tr>
      <td><label for="exampleFormControlInput1"> Enter stock price </label></td>
   <td> <input type="text" class="form-control" placeholder="stock price" name="stock_price"> </td></tr>

   <tr>
      <td><label for="exampleFormControlInput1"> Enter selling price </label></td>
   <td> <input type="text" class="form-control" placeholder="selling price" name="selling_price"> </td></tr>

<tr>
     <td><label for="exampleFormControlInput1"> date of stock </label></td>
   <td> <input type="text" class="form-control" placeholder="date of stock" name="date_of_stock"> </td> </tr>

   <tr>
    <td><label for="exampleFormControlInput1"> expiry date </label></td>
    <td><input type="text" class="form-control" placeholder="expiry date" name="expiry_date"> </td>
    </tr>


    <!--////select repective product image and video///-->
   <input type="hidden"  name="product_image" value="{{$product->product_image}}"> 
   <input type="hidden"  name="product_video" value="{{$product->product_video}}"> 

      <td><button type="submit" class="btn btn-secondary">Stock Product </button></td>
     
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>


</form>


</div>

<div  class=" col-md-6 " style="background-color: rgb(12,56,45);color:white; ">
 
<table style="color:white">
<th><h2>Company name:  </h2></th>
<th><h2>Company code:  </h2></th>
<th><h2>Company code:  </h2></th>
<th><h2>Company code:  </h2></th>
@foreach($stocks as $stock)


<tr>
<td>
<a href="{{-- url ('company_edit_show',$company->id)--}}"> {{ $stock->Productlist['product_name'] }}</a>

</td>
<td>
 {{ $stock->batch_num }}

</td>
<td>
 {{ $stock->order_status }}

</td>
<td>
 {{ $stock->profit }}

</td>

</tr>

@endforeach
 </table>

</div>




</div>

@endsection

