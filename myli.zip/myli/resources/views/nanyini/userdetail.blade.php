
@extends('dbbody.useredit')
@section('userdetail')

<h3> User Credentials </h3>

  <table class="table" >
  <thead style="color:white; ">
    <tr>
      
      <th style="width: 10%">Name</th>
      <th style="width: 10%">Email</th>
      <th style="width: 10%">Stake Holder</th>
      
      <th style="width: 40%">Assign New Role</th>
      <th style="width: 10%">Updated At</th>
      <th style="width: 10%">Created At</th>

     
    </tr>
  </thead>
  <tbody >
    <form method="post" action="{{route('dbbody.update',[$userdet->id])}}" enctype="multipart/form-data">
    {{csrf_field()}}
    <input type="hidden" name="_method" value="put">
    <tr>
    @if(!empty($userdet))
     <td> <input type="text"  name="user_name" value=" {{ $userdet->name }}">  </td>
      <td><input type="text"  name="user_email" value="{{ $userdet->email }}"> </td>
      <td>
      <select name="stake_holder">
          <option value="{{$userdet->stake_holder}}">{{ $userdet->Stakeholder['stake_holder_ctgry'] }}</option>
          @foreach($stake_holder as $user_stake_holder )
        <option value="{{$user_stake_holder->id}}">{{ $user_stake_holder->stake_holder_ctgry }}</option>
        @endforeach
      </select>
    </td>
      <td  >
        <select name="user_role">
          <option value="{{$userdet->role}}">{{ $userdet->Roles['role_type'] }}</option>
          @foreach($role as $user_role )
        <option value="{{$user_role->id}}">{{ $user_role->role_type }}</option>
        @endforeach
        </select>
      </td>
      <td>{{ $userdet->updated_at }}</td>
      <td>{{ $userdet->created_at }}</td>
      <td><button type="submit" class="btn btn-primary">Update Changes</button></td>
      @endif
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>

@endsection