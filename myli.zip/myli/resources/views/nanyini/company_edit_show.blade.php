
@extends('nanyini.company_edit')
@section('company_edit_show')

<h3> Company Credentials </h3>

  <table class="table" >
  <thead style="color:white; ">
    <tr>
      
      <th style="width: 10%">Company Name</th>
      <th style="width: 10%">Compnay code</th>
      

     
    </tr>
  </thead>
  <tbody >
    <form method="post" action="{{ url('company_update',[$company->id]) }}" enctype="multipart/form-data">
    {{csrf_field()}}
    <input type="hidden" name="_method" value="put">
    <tr>
    @if(!empty($company))
     <td> <input type="text"  name="update_company_name" value=" {{ $company->company_name }}">  </td>
      <td><input type="text"  name="update_company_code" value="{{ $company->unique_id }}"> </td>
      
      <td>{{ $company->updated_at }}</td>
      
      <td><button type="submit" class="btn btn-primary">Update Changes</button></td>
      @endif
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>

@endsection