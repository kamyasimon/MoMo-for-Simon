@extends('dashboard.dboard')
@section('company_edit')

<h1>You are at Company Edit</h2>
<div class="container" >
<div class="navbar col-md-4 " style="overflow-y: scroll;">
<form  action="create_company" method="post" enctype="multipart/form-data">
    {{csrf_field()}}



  <div class="form-group">
    <label > Create Company Name </label>
    <input type="text" class="form-control"  placeholder="new company name" name="new_company_name">
  </div>
    <div class="form-group">
    <label for="exampleFormControlInput1"> Create Company Unique Code </label>
    <input type="text" class="form-control" placeholder="new Unique code" name="new_company_code">
  </div>
   
  <div class="form-group">
    
    <button type="submit" class="btn btn-secondary">Create Company </button>
  </div>
</form>

<table>
<th><h2>Company name:  </h2></th>
<th><h2>Company code:  </h2></th>
@foreach($companies as $company)


<tr>
<td>
<a href="{{ url ('company_edit_show',$company->id)}}"> {{ $company->company_name }}</a>

</td>
<td>
 {{ $company->unique_id }}

</td>
</tr>

@endforeach
 </table>
</div>

<div  class=" col-md-8 " style="background-color: rgb(12,56,45);color:white; ">
 
@yield ('company_edit_show')

</div>

</div>

@endsection

