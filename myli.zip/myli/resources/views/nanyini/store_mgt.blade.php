@extends('dashboard.dboard')
@section('super_store')

<h1>You are at Product Stock Management</h2>
<div class="container" >
<div class="navbar col-md-6 " style="overflow-y: scroll;">


  <table class="table" >
  <thead style="color:brown; ">
    <tr>
      
      <th></th>

     
    </tr>
  </thead>
  <tbody >

    <form action="create_store" method="post" enctype="multipart/form-data">
    {{csrf_field()}}

   

      <tr>
      <td><label for="exampleFormControlInput1"> Enter store name </label></td>
   <td> <input type="text" class="form-control" placeholder="new store name" name="new_store_name"> </td></tr>

   <tr>
      <td><label for="exampleFormControlInput1"> Enter store code </label></td>
   <td> <input type="text" class="form-control" placeholder="new store code" name="new_store_code"> </td></tr>

 
   <tr>
      <td><label for="exampleFormControlInput1"> Enter location </label></td>
   <td> <input type="text" class="form-control" placeholder="new store location" name="new_store_location"> </td></tr>

      <td><button type="submit" class="btn btn-secondary">create Store </button></td>
     
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>


</form>


</div>

<div  class=" col-md-6 " style="background-color: rgb(12,56,45);color:white; ">
 
<table style="color:white">
<th><h2>store name:  </h2></th>
<th><h2>store code:  </h2></th>
<th><h2>store location:  </h2></th>

@foreach($stores as $store)


<tr>
<td>
<a href="{{-- url ('company_edit_show',$company->id)--}}"> {{ $store->store_name }}</a>

</td>
<td>
 {{ $store->unique_id }}

</td>
<td>
 {{ $store->location }}

</td>


</tr>

@endforeach
 </table>

</div>




</div>

@endsection

