<h3> User Credentials </h3>

  <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Name</th>
      <th scope="col">Email</th>
     
    </tr>
  </thead>
  <tbody>
    @foreach($users as $userz)
    <tr>
      
      <td>{{$userz->name}}</td>
      <td>{{$userz->email}}</td>
     
      
    </tr>
    @endforeach
   
  </tbody>
</table>
