@extends('layouts.app')
@section('content')

<h1>Your shopping cart</h2>
<div class="container" >
<div class="navbar col-md-6 " style="overflow-y: scroll;">


  <table class="table" >
  <thead style="color:brown; ">
    <tr>
      
      <th></th>

     
    </tr>
  </thead>
  <tbody >

    <form action="create_store" method="post" enctype="multipart/form-data">
    {{csrf_field()}}

   

      <tr>
      <td><label for="exampleFormControlInput1"> Enter store name </label></td>
   <td> <input type="text" class="form-control" placeholder="new store name" name="new_store_name"> </td></tr>

   <tr>
      <td><label for="exampleFormControlInput1"> Enter store code </label></td>
   <td> <input type="text" class="form-control" placeholder="new store code" name="new_store_code"> </td></tr>

 
   <tr>
      <td><label for="exampleFormControlInput1"> Enter location </label></td>
   <td> <input type="text" class="form-control" placeholder="new store location" name="new_store_location"> </td></tr>

      <td><button type="submit" class="btn btn-secondary">create Store </button></td>
     
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>


</form>






</div>

@endsection

