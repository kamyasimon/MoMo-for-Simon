


<h2>Company name:  <a href="{{--route('pac.show',[$report->id])--}}"> {{--$report->report_name--}}</a></h2>




