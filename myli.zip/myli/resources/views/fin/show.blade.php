@extends('layouts.app')
@section('content')


<h2>Report name:  {{$report->report_name}}</h2>
<h2>Year published:  {{$report->year_published}}</h2>
<h2>Report Status:  {{$report->status}}</h2>
<div><h2>Report Summary</h2>

<p>Report Summary:{{$report->report_summery}}</p>
</div>
<div>
	<p>Key findings : {{$report->key_findings}}</p>
</div>
<div>
	<p>Recommendations_AG: {{$report->Recommendations_AG}}</p>
</div>
<div>
	<p>Attached file: {{$report->attachment_name}}</p>
</div>
<div>
	<p>Recommendations_PAC :{{$report->Recommendations_PAC}}</p>
</div>

<div>
	<form method="post" action="{{route('paledit.update',[$report->id])}}" enctype="multipart/form-data">
    {{csrf_field()}}
    <input type="hidden" name="_method" value="put">

	<div class="form-group">
    <label for="exampleFormControlTextarea1">Action by Finance</label>
    <textarea name = "action_by_finace" class="form-control" id="exampleFormControlTextarea1" rows="3">{{$report->action_by_finace}}</textarea>
    <button type="submit" class="btn btn-success">Submit</button>
    </form>
  </div>
</div>

@endsection