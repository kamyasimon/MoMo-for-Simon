@extends('layouts.app')
@section('content')


<h2>Report name:  {{$report->report_name}}</h2>
<h2>Year published:  {{$report->year_published}}</h2>
<h2>Report Status:  {{$report->status}}</h2>
<div><h2>Report Summary</h2>

<p>{{$report->report_summery}}</p>
</div>
<div>
	<p>{{$report->key_findings}}</p>
</div>
<div>
	<p>{{$report->Recommendations_AG}}</p>
</div>
<div>
	<p>{{$report->attachment_name}}</p>
</div>
<div>
	<p>Recommendations_PAC :{{$report->Recommendations_PAC}}</p>
</div>

@if(Auth::user()->role != 3)
<div>
	<p>Action by Finance: {{$report->action_by_finace}}</p>
</div>
<div>
	<p>Action by Auditee: {{$report->action_by_auditee}}</p>
</div>
<div>
	<p>{{$report->action_by_directorate}}</p>
</div>
<div>
	<p>{{$report->action_by_questions}}</p>
</div>
<div>
	<p>{{$report->action_by_provisional_summery}}</p>
</div>

@endif
 <div>


    <label>Question 1 : Has the report been discussed</label><br><p>{{$question->question_1}}</p>

    <label>Question 2: Has the oversight committee prepared a report</label><br><p>{{$question->question_2}}</p>

    <label>Question 3: Has the report been presented to the floor</label><br><p>{{$question->question_3}}</p>

    <label>Question 4: Has the report been adopted</label><br><p>{{$question->question_4}}</p>

    <label>Question 5: Has the clerk to Parliament written to the leader of Government Business</label><br><p>{{$question->question_5}}</p>

    <label>Question 6: Has the leader of Government Business Taken Action</label><br> <p>{{$question->question_6}}</p>

    <label>Question 7: Has the Ministry of Finance Prepared Treasury Memoranda</label><br><p>{{$question->question_7}}</p>
 
  </div>

@endsection