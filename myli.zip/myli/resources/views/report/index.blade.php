@extends('layouts.app')
@section('content')

@foreach($report as $report)
<h2>Report name:  <a href="{{route('report.show',[$report->id])}}"> {{$report->report_name}}</a></h2>

@endforeach



@endsection
