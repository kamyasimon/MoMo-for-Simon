<?php $__env->startSection('content'); ?>


<h2>Report name:   <?php echo e($report -> id); ?> </h2>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\wamp64\www\oagrep\resources\views/paledit/index.blade.php */ ?>