<?php $__env->startSection('content'); ?>


<h2>Report name:  <?php echo e($report->report_name); ?></h2>
<h2>Report name:  <?php echo e($report->year_published); ?></h2>
<h2>Report name:  <?php echo e($report->status); ?></h2>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\wamp64\www\oagrep\resources\views/report/show.blade.php */ ?>