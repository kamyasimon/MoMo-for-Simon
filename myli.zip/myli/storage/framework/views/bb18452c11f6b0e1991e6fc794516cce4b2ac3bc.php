<?php $__env->startSection('useredit'); ?>
<h1>welcome to user edit</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\laragon\www\ats\resources\views/dbbody/usersedit.blade.php */ ?>