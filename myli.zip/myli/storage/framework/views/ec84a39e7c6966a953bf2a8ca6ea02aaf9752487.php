<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h2>Report name:  <a href="<?php echo e(route('report.show',[$report->id])); ?>"> <?php echo e($report->report_name); ?></a></h2>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\wamp64\www\oagrep\resources\views/report/index.blade.php */ ?>