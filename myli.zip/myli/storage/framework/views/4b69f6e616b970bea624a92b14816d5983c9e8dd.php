<?php $__env->startSection('super_store'); ?>

<h1>You are at Product Stock Management</h2>
<div class="container" >
<div class="navbar col-md-6 " style="overflow-y: scroll;">


  <table class="table" >
  <thead style="color:brown; ">
    <tr>
      
      <th></th>

     
    </tr>
  </thead>
  <tbody >

    <form action="create_store" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


   

      <tr>
      <td><label for="exampleFormControlInput1"> Enter store name </label></td>
   <td> <input type="text" class="form-control" placeholder="new store name" name="new_store_name"> </td></tr>

   <tr>
      <td><label for="exampleFormControlInput1"> Enter store code </label></td>
   <td> <input type="text" class="form-control" placeholder="new store code" name="new_store_code"> </td></tr>

 
   <tr>
      <td><label for="exampleFormControlInput1"> Enter location </label></td>
   <td> <input type="text" class="form-control" placeholder="new store location" name="new_store_location"> </td></tr>

      <td><button type="submit" class="btn btn-secondary">create Store </button></td>
     
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>


</form>


</div>

<div  class=" col-md-6 " style="background-color: rgb(12,56,45);color:white; ">
 
<table style="color:white">
<th><h2>store name:  </h2></th>
<th><h2>store code:  </h2></th>
<th><h2>store location:  </h2></th>

<?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
<td>
<a href=""> <?php echo e($store->store_name); ?></a>

</td>
<td>
 <?php echo e($store->unique_id); ?>


</td>
<td>
 <?php echo e($store->location); ?>


</td>


</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </table>

</div>




</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* J:\MTN CHALLENGE\myli\resources\views/nanyini/store_mgt.blade.php */ ?>