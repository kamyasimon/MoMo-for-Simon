<?php $__env->startSection('product_list'); ?>

<h1>You are at Product List Management</h2>
<div class="container"  >
<div class="navbar col-md-4 " >


<h3> Enter Product Details </h3>

  <table class="table-responsive" style="" >
  <thead style="color:brown; background-color: pink;">
   
  
      <th style="width: 10%"><h2>Product name:  </h2></th>
      <th style="width: 10%"><h2>Category:  </h2></th>
      <th style="width: 10%"><h2>Related Category: A  </h2></th>
      <th style="width: 10%"><h2>Related Category: B  </h2></th>
      <th style="width: 10%"><h2>Related Category: C  </h2></th>
      <th style="width: 10%"><h2>Shelf Number:  </h2></th>
      
  </thead>
  <tbody >
    <form action="new_product" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

   
    <tr style="background-color: pink;height: 50px;">
   
  <td><input type="text" class="form-control"  placeholder="new product name" name="new_product_name">
      </td> 

    
       <td>
      <select name="new_product_category">
                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select>
  
  </td>

  
      
      <td>
      <select name="related_category_a">
           <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <option value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select>
    </td>


  
      <td>
      <select name="related_category_b">
                 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <option value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select>
    </td>
  
      
      <td>
      <select name="related_category_c">
                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <option value="<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select>
    </td>
 
  
   <td> <input type="text" class="form-control" placeholder="shelf code" name="new_shelf_number"> </td> </tr>

   <thead style="color:brown;background-color: yellow;">
     <th style="width: 10%"><h2>Visibility:  </h2></th>
     
      <th style="width: 10%"><h2>Producer Company:  </h2></th>
      <th style="width: 10%"><h2>Product Image  </h2></th>
      <th style="width: 10%"><h2>Product Video Link </h2></th>
</thead>
      <tr style="background-color: yellow;height: 50px;">
       <td>
      <select name="visibility">
                   
        <option value="0"> Not Visible </option>
        <option value="1"> Visible </option>
       
      </select>
    </td>
    

     <td>
        <select name="producer_company">
         <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($company->id); ?>"><?php echo e($company->company_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </td>
     
         
      
     
          <td>
       <input   type="file" name="image_file"  style="background-color:#ffffff;color:rgb(255,14,14);">
       </td>
    
      <td>
        <input type="text" class="form-control" placeholder="video link" name="video_link">
        
      </td>
      <td><button type="submit" class="btn btn-secondary">Create  Product </button></td>
      </tr>



      
     
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>

</div>
<hr style="height: 12px; background-color: lime;">
</form>

<table>
<th><h2>Product name:  </h2></th>
<th><h2>Category:  </h2></th>
<th><h2>Shelf Number:  </h2></th>
<th><h2>Visibility:  </h2></th>
<th><h2>Stock Price:  </h2></th>
<th><h2>Selling Price:  </h2></th>
<th><h2>Profit:  </h2></th>
<th><h2>Producer Company:  </h2></th>
<th><h2>Product Image  </h2></th>
<th><h2>Product Video  </h2></th>

<!--foreach($products as $product)-->


<tr>
<td>
<a href=""> </a>

</td>
<td>
 

</td>
</tr>

<!--endforeach-->

 </table>
</div>

<div  class=" col-md-8 " style="background-color: rgb(12,56,45);color:white; ">
 
<!--yield ('company_edit_show')-->

</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* J:\MTN CHALLENGE\myli\resources\views/nanyini/product_list.blade.php */ ?>