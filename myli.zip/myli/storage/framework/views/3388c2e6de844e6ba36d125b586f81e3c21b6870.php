<?php $__env->startSection('userdetail'); ?>

<h3> User Credentials </h3>

  <table class="table" >
  <thead style="color:white; ">
    <tr>
      
      <th style="width: 10%">Name</th>
      <th style="width: 10%">Email</th>
      <th style="width: 10%">Stake Holder</th>
      
      <th style="width: 40%">Assign New Role</th>
      <th style="width: 10%">Updated At</th>
      <th style="width: 10%">Created At</th>

     
    </tr>
  </thead>
  <tbody >
    <form method="post" action="<?php echo e(route('dbbody.update',[$userdet->id])); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="_method" value="put">
    <tr>
    <?php if(!empty($userdet)): ?>
     <td> <input type="text"  name="user_name" value=" <?php echo e($userdet->name); ?>">  </td>
      <td><input type="text"  name="user_email" value="<?php echo e($userdet->email); ?>"> </td>
      <td>
      <select name="stake_holder">
          <option value="<?php echo e($userdet->stake_holder); ?>"><?php echo e($userdet->Stakeholder['stake_holder_ctgry']); ?></option>
          <?php $__currentLoopData = $stake_holder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_stake_holder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($user_stake_holder->id); ?>"><?php echo e($user_stake_holder->stake_holder_ctgry); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </td>
      <td  >
        <select name="user_role">
          <option value="<?php echo e($userdet->role); ?>"><?php echo e($userdet->Roles['role_type']); ?></option>
          <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($user_role->id); ?>"><?php echo e($user_role->role_type); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </td>
      <td><?php echo e($userdet->updated_at); ?></td>
      <td><?php echo e($userdet->created_at); ?></td>
      <td><button type="submit" class="btn btn-primary">Update Changes</button></td>
      <?php endif; ?>
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dbbody.useredit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\laragon\www\ats\resources\views/dbbody/userdetail.blade.php */ ?>