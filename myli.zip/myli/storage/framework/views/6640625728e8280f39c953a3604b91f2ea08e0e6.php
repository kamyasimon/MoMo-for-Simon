<?php $__env->startSection('categories'); ?>
{--//////CREATE NEW CATEGORY////--}
<div>
  
<form  action="add_category" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>




  <div class="form-group">
    <label > Create New Category </label>
    <input type="text" class="form-control"  placeholder="new Category name" name="new_category_name">
  </div>
    
  <div class="form-group">
    
    <button type="submit" class="btn btn-secondary">Create Category </button>
  </div>
</form>


</div>

{--//////SHOW CATEGORY////--}
<div>
  

<table>
<th><h2>Category name:  </h2></th>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
<td>
<a href=""> <?php echo e($category->category_name); ?></a>

</td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </table>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* J:\MTN CHALLENGE\myli\resources\views/nanyini/categories.blade.php */ ?>