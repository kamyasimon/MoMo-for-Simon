<?php $__env->startSection('stats'); ?>
<h1>welcome to statistics</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* J:\MTN CHALLENGE\myli\resources\views/nanyini/stats.blade.php */ ?>