<?php /* I:\oagrep\resources\views/report/show.blade.php */ ?>
<?php $__env->startSection('content'); ?>


<h1>Report name: <?php echo e($report -> report_name); ?> </h1>
<p>Year Published: <?php echo e($report -> year_published); ?> </p>
<p>Reprt Summery: <?php echo e($report -> report_summery); ?> </p>
<p>Status: <?php echo e($report -> status); ?> </p>
<p>Key Findings: <?php echo e($report -> key_findings); ?> </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>