<?php $__env->startSection('welcome'); ?>
<h1>welcomeDB WELCOME</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* J:\MTN CHALLENGE\myli\resources\views/dbbody/dbwelcome.blade.php */ ?>