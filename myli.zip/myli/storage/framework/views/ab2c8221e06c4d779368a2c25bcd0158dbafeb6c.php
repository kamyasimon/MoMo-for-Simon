<?php $__env->startSection('content'); ?>


<div class="row">
	<h2>Report name:  <a href="<?php echo e(route('report.show',[$report->id])); ?>"> <?php echo e($report->report_name); ?></a></h2>
  <h2>Year Published:  <?php echo e($report->year_published); ?></h2>
</div>
<form method="post" action="<?php echo e(route('paledit.update',[$report->id])); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="_method" value="put">
  <div class="form-group">
    <label for="exampleFormControlInput1">Report Summery</label>
    <textarea class="form-control" type="input" rows="3" name='report_summery'><?php echo e($report->report_summery); ?></textarea>
  </div>
    <div class="form-group">
    <label for="exampleFormControlInput1">Report Keyfindings</label>
    <textarea class="form-control" type="input" rows="3" name='keyfindings'><?php echo e($report->report_key_findings); ?></textarea>
  
  <div class="form-group">
    <label for="exampleFormControlSelect1">Report Status</label>
    <select class="form-control" id="exampleFormControlSelect1" name='report_status'>
      <option value='pending'>Pending</option>
      <option value='fowarded'>Forward for Submission </option>
      
    </select>
  </div>

  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Example textarea</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
 <div>


    <label>Question 1 : Has the report been discussed</label><br><select name="q1"> <option value="pending">Pending</option><option value="yes">Yes</option>
  <option value="no">No</option></select><br>

    <label>Question 2: Has the oversight committee prepared a report</label><br><select name="q2"> <option value="pending">Pending</option><option value="yes">Yes</option>
  <option value="no">No</option></select><br>

    <label>Question 3: Has the report been presented to the floor</label><br><select name="q3"> <option value="pending">Pending</option><option value="yes">Yes</option>
  <option value="no">No</option></select><br>

    <label>Question 4: Has the report been adopted</label><br><select name="q4"> <option value="pending">Pending</option><option value="yes">Yes</option>
  <option value="no">No</option></select><br>

    <label>Question 5: Has the clerk to Parliament written to the leader of Government Business</label><br><select name="q5"> <option value="pending">Pending</option><option value="yes">Yes</option>
  <option value="no">No</option></select><br>

    <label>Question 6: Has the leader of Government Business Taken Action</label><br><select name="q6"> <option value="pending">Pending</option><option value="yes">Yes</option>
  <option value="no">No</option></select><br>

    <label>Question 7: Has the Ministry of Finance Prepared Treasury Memoranda</label><br><select name="q7"> <option value="pending">Pending</option><option value="yes">Yes</option>
  <option value="no">No</option></select><br>
 
  </div>



  <button type="submit" class="btn btn-default" >Save</button>
 
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\laragon\www\ats\resources\views/paledit/show.blade.php */ ?>