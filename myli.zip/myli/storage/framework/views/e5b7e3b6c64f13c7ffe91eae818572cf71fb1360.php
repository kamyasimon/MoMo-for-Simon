<?php $__env->startSection('add_stock'); ?>

<h1>You are at Product Stock Management</h2>
<div class="container" >
<div class="navbar col-md-6 " style="overflow-y: scroll;">


  <table class="table" >
  <thead style="color:brown; ">
    <tr>
      
      <th></th>

     
    </tr>
  </thead>
  <tbody >

    <form action="add_stock" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


    <tr>
    <td><label for="exampleFormControlInput1"> Produce Company </label></td>
      <td>
        <select name="company" style="width: 90%">
          
         <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($company -> id); ?>"><?php echo e($company -> company_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </td>
      </tr>


   <tr>
      <td><label for="exampleFormControlInput1"> Category </label></td>
      <td>
      <select name="category" style="width: 90%">
          
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <option value="<?php echo e($category->id); ?>" ><?php echo e($category->category_name); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select>
    </td>
    </tr>
    <tr>
      <td><label for="exampleFormControlInput1"> Product name </label></td>
      <td>
      <select name="product_name" style="width: 90%">
          
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <option value="<?php echo e($product->id); ?>" ><?php echo e($product->product_name); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select>
    </td>
    </tr>
      <tr>
      <td><label for="exampleFormControlInput1"> Enter batch Code </label></td>
   <td> <input type="text" class="form-control" placeholder="product batch number" name="product_batch_number"> </td></tr>

   <tr>
      <td><label for="exampleFormControlInput1"> Enter stock price </label></td>
   <td> <input type="text" class="form-control" placeholder="stock price" name="stock_price"> </td></tr>

   <tr>
      <td><label for="exampleFormControlInput1"> Enter selling price </label></td>
   <td> <input type="text" class="form-control" placeholder="selling price" name="selling_price"> </td></tr>

<tr>
     <td><label for="exampleFormControlInput1"> date of stock </label></td>
   <td> <input type="text" class="form-control" placeholder="date of stock" name="date_of_stock"> </td> </tr>

   <tr>
    <td><label for="exampleFormControlInput1"> expiry date </label></td>
    <td><input type="text" class="form-control" placeholder="expiry date" name="expiry_date"> </td>
    </tr>


    <!--////select repective product image and video///-->
   <input type="hidden"  name="product_image" value="<?php echo e($product->product_image); ?>"> 
   <input type="hidden"  name="product_video" value="<?php echo e($product->product_video); ?>"> 

      <td><button type="submit" class="btn btn-secondary">Stock Product </button></td>
     
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>


</form>


</div>

<div  class=" col-md-6 " style="background-color: rgb(12,56,45);color:white; ">
 
<table style="color:white">
<th><h2>Company name:  </h2></th>
<th><h2>Company code:  </h2></th>
<th><h2>Company code:  </h2></th>
<th><h2>Company code:  </h2></th>
<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
<td>
<a href=""> <?php echo e($stock->Productlist['product_name']); ?></a>

</td>
<td>
 <?php echo e($stock->batch_num); ?>


</td>
<td>
 <?php echo e($stock->order_status); ?>


</td>
<td>
 <?php echo e($stock->profit); ?>


</td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </table>

</div>




</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* J:\MTN CHALLENGE\myli\resources\views/nanyini/add_stock.blade.php */ ?>