<?php $__env->startSection('content'); ?>


<h2>Report name:  <?php echo e($report->report_name); ?></h2>
<h2>Year published:  <?php echo e($report->year_published); ?></h2>
<h2>Report Status:  <?php echo e($report->status); ?></h2>
<div><h2>Report Summary</h2>

<p><?php echo e($report->report_summery); ?></p>
</div>
<div>
	<p><?php echo e($report->key_findings); ?></p>
</div>
<div>
	<p><?php echo e($report->Recommendations_AG); ?></p>
</div>
<div>
	<p><?php echo e($report->attachment_name); ?></p>
</div>
<div>
	<p>Recommendations_PAC :<?php echo e($report->Recommendations_PAC); ?></p>
</div>

<?php if(Auth::user()->role != 3): ?>
<div>
	<p>Action by Finance: <?php echo e($report->action_by_finace); ?></p>
</div>
<div>
	<p>Action by Auditee: <?php echo e($report->action_by_auditee); ?></p>
</div>
<div>
	<p><?php echo e($report->action_by_directorate); ?></p>
</div>
<div>
	<p><?php echo e($report->action_by_questions); ?></p>
</div>
<div>
	<p><?php echo e($report->action_by_provisional_summery); ?></p>
</div>

<?php endif; ?>
 <div>


    <label>Question 1 : Has the report been discussed</label><br><p><?php echo e($question->question_1); ?></p>

    <label>Question 2: Has the oversight committee prepared a report</label><br><p><?php echo e($question->question_2); ?></p>

    <label>Question 3: Has the report been presented to the floor</label><br><p><?php echo e($question->question_3); ?></p>

    <label>Question 4: Has the report been adopted</label><br><p><?php echo e($question->question_4); ?></p>

    <label>Question 5: Has the clerk to Parliament written to the leader of Government Business</label><br><p><?php echo e($question->question_5); ?></p>

    <label>Question 6: Has the leader of Government Business Taken Action</label><br> <p><?php echo e($question->question_6); ?></p>

    <label>Question 7: Has the Ministry of Finance Prepared Treasury Memoranda</label><br><p><?php echo e($question->question_7); ?></p>
 
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\laragon\www\ats\resources\views/report/show.blade.php */ ?>