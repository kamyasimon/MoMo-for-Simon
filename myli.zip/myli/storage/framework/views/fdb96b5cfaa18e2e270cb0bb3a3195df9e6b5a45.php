<?php $__env->startSection('content'); ?>


<div class="row">
	<h2>Report name:  <a href="<?php echo e(route('report.show',[$report->id])); ?>"> <?php echo e($report->report_name); ?></a></h2>
</div>
<form>
    <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label for="exampleFormControlInput1">Enter Report Name</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
    <div class="form-group">
    <label for="exampleFormControlInput1">Enter Report Keyword</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
    <div class="form-group">
    <label for="exampleFormControlInput1">Enter Report Password</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Example select</label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect2">Example multiple select</label>
    <select multiple class="form-control" id="exampleFormControlSelect2">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>5</option>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Example textarea</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* I:\oagrep\resources\views/paledit/show.blade.php */ ?>