<?php $__env->startSection('adminreport'); ?>
<h1>welcome to admin reports</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\laragon\www\ats\resources\views/dbbody/adminreport.blade.php */ ?>