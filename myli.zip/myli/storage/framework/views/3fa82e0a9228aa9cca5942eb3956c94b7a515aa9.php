<?php $__env->startSection('company_edit'); ?>

<h1>You are at Company Edit</h2>
<div class="container" >
<div class="navbar col-md-4 " style="overflow-y: scroll;">
<form  action="create_company" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>




  <div class="form-group">
    <label > Create Company Name </label>
    <input type="text" class="form-control"  placeholder="new company name" name="new_company_name">
  </div>
    <div class="form-group">
    <label for="exampleFormControlInput1"> Create Company Unique Code </label>
    <input type="text" class="form-control" placeholder="new Unique code" name="new_company_code">
  </div>
   
  <div class="form-group">
    
    <button type="submit" class="btn btn-secondary">Create Company </button>
  </div>
</form>

<table>
<th><h2>Company name:  </h2></th>
<th><h2>Company code:  </h2></th>
<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
<td>
<a href="<?php echo e(url ('company_edit_show',$company->id)); ?>"> <?php echo e($company->company_name); ?></a>

</td>
<td>
 <?php echo e($company->unique_id); ?>


</td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </table>
</div>

<div  class=" col-md-8 " style="background-color: rgb(12,56,45);color:white; ">
 
<?php echo $__env->yieldContent('company_edit_show'); ?>

</div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* J:\MTN CHALLENGE\myli\resources\views/nanyini/company_edit.blade.php */ ?>