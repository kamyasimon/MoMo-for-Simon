<?php $__env->startSection('content'); ?>


<div class="row">
	<h2>Report name:  <a href="<?php echo e(route('report.show',[$report->id])); ?>"> <?php echo e($report->report_name); ?></a></h2>
  <h2>Year Published:  <?php echo e($report->year_published); ?></h2>
</div>
<form method="post" action="<?php echo e(route('paledit.update',[$report->id])); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="_method" value="put">
  <div class="form-group">
    <label for="exampleFormControlInput1">Report Summery</label>
    <textarea class="form-control" type="input" rows="3" name='report_summery'></textarea>
  </div>
    <div class="form-group">
    <label for="exampleFormControlInput1">Report Keyfindings</label>
    <textarea class="form-control" type="input" rows="3" name='keyfindings'></textarea>
  
  <div class="form-group">
    <label for="exampleFormControlSelect1">Report Status</label>
    <select class="form-control" id="exampleFormControlSelect1" name='report_status'>
      <option value='pending'>Pending</option>
      <option value='fowarded'>Forward for Submission </option>
      
    </select>
  </div>

  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Example textarea</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
  <button type="submit" class="btn btn-default" >Save</button>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\wamp64\www\oagrep\resources\views/paledit/show.blade.php */ ?>