<?php $__env->startSection('company_edit_show'); ?>

<h3> Company Credentials </h3>

  <table class="table" >
  <thead style="color:white; ">
    <tr>
      
      <th style="width: 10%">Company Name</th>
      <th style="width: 10%">Compnay code</th>
      

     
    </tr>
  </thead>
  <tbody >
    <form method="post" action="<?php echo e(url('company_update',[$company->id])); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="_method" value="put">
    <tr>
    <?php if(!empty($company)): ?>
     <td> <input type="text"  name="update_company_name" value=" <?php echo e($company->company_name); ?>">  </td>
      <td><input type="text"  name="update_company_code" value="<?php echo e($company->unique_id); ?>"> </td>
      
      <td><?php echo e($company->updated_at); ?></td>
      
      <td><button type="submit" class="btn btn-primary">Update Changes</button></td>
      <?php endif; ?>
      
      
     
      
    </tr>
  </form>
   
   
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('nanyini.company_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* J:\MTN CHALLENGE\myli\resources\views/nanyini/company_edit_show.blade.php */ ?>