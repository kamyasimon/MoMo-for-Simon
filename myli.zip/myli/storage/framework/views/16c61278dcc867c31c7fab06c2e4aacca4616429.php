<?php $__env->startSection('content'); ?>


<h2>Report name:  <?php echo e($report->report_name); ?></h2>
<h2>Year published:  <?php echo e($report->year_published); ?></h2>
<h2>Report Status:  <?php echo e($report->status); ?></h2>
<div><h2>Report Summary</h2>

<p><?php echo e($report->report_summery); ?></p>
</div>
<div>
	<p><?php echo e($report->key_findings); ?></p>
</div>
<div>
	<p><?php echo e($report->Recommendations_AG); ?></p>
</div>
<div>
	<p><?php echo e($report->attachment_name); ?></p>
</div>


<div>
	<form method="post" action="<?php echo e(route('paledit.update',[$report->id])); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="_method" value="put">

	<div class="form-group">
    <label for="exampleFormControlTextarea1">Reccomedations by PAC</label>
    <textarea name = "Recommendations_PAC" class="form-control" id="exampleFormControlTextarea1" rows="3"><?php echo e($report->Recommendations_PAC); ?></textarea>
    <button type="submit" class="btn btn-success">Submit</button>
    </form>
  </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\laragon\www\ats\resources\views/pac/show.blade.php */ ?>