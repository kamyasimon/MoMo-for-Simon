<?php $__env->startSection('useredit'); ?>
<h1>welcome to user edit</h1>
<div class="container">
<div class="navbar col-lg-2">
  
  <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Bootstrap Sidebar</h3>
            </div>

              <ol>
 
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <li>
    <a href="<?php echo e(url ('userdetail',$user->id)); ?> "> 
    <?php echo e($user->name); ?>

  </a>

  </li>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </ol>
        </nav>

 

 
</div>







<div  class="col-lg-10" style="background-color: rgb(12,56,45);color:white; ">
 
<?php echo $__env->yieldContent('userdetail'); ?>

</div>

</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.dboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\laragon\www\ats\resources\views/dbbody/useredit.blade.php */ ?>