<?php $__env->startSection('content'); ?>
<div style="width: 400px; height: 200px; overflow-y: scroll; margin-left: 150px; ">
<?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<h2>Report name:  <a href="<?php echo e(route('report.show',[$report->id])); ?>"> <?php echo e($report->report_name); ?></a></h2>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row" style=" margin-left: 150px; margin-top: 100px">
	
	<form action="/create_report" method="post" enctype="multipart/form-data">
           
            <?php echo e(csrf_field()); ?>

		
      <div class="form-group">
    <label for="exampleFormControlInput1">Enter Report Name</label>
    <input type="input" class="form-control" id="exampleFormControlInput1" name ="report_name" placeholder="Report name">

      <label for="exampleFormControlInput1">Year Published</label>
    <input type="input" class="form-control" id="exampleFormControlInput1" name ="year_published" placeholder="year published">

    <button type="submit" class="btn btn-secondary">Create new Report</button>
  </div>
  
	</form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\wamp64\www\oagrep\resources\views/pal/index.blade.php */ ?>