<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductListTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_list', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('product_name');
            $table->string('shelf_number')->unique();
            $table->integer('visibilty')->default(0);
           
            $table->string('product_image')->nullable();
            $table->string('product_video')->nullable();
            $table->string('related_category_a')->nullable();
            $table->string('related_category_b')->nullable();
            $table->string('related_category_c')->nullable();

            $table->timestamps();


            ///FOREIGN KEYS /////
            $table->integer('company_product')->unsigned();
            $table->foreign('company_product')->references('id')->on('companies');
            $table->integer('product_category')->unsigned();
            $table->foreign('product_category')->references('id')->on('categories');
            
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_list');
    }
}
