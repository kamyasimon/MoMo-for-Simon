<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdvertVideosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('advert_videos', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('advert_video_name');
            $table->integer('adv_visibilty')->default(0);
            $table->string('ad_video_url')->nullable();
            $table->string('ad_video_key')->nullable();
            $table->string('go_to_ad_url')->nullable();


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('advert_videos');
    }
}
