<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('transaction_type')->default('purchase');
            $table->string('transaction_status')->default('pending');
            $table->integer('transaction_number')->unique()->default(0);
            $table->string('xref_id')->nullable();
            $table->string('transaction_token')->nullable();
            $table->integer('purchase_amount')->default(0);
            $table->integer('refunded_amount')->default(0);
            $table->timestamps();


            ///FOREIGN KEYS /////
            $table->integer('account_name')->unsigned();
           $table->foreign('account_name')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
