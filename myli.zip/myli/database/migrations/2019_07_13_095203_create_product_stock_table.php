<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductStockTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_stock', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('product_name')->unsigned();
            $table->foreign('product_name')->references('id')->on('product_list');
            $table->string('batch_num')->unique();
             $table->integer('stock_price')->default(0);
            $table->integer('selling_price')->default(0);
            $table->integer('profit')->default(0);
            $table->string('status')->default('stocked');
            $table->string('date_of_stock')->nullable();
            $table->string('order_status')->default('not sold');
            $table->string('date_sold')->nullable();
            $table->string('durability');
            $table->integer('rating')->default(0);
            $table->integer('visits')->default(0);
            
            


            $table->timestamps();


            ///FOREIGN KEYS /////
            $table->integer('stock_entered_by')->unsigned();
            $table->foreign('stock_entered_by')->references('id')->on('users');
            $table->integer('bought_by_customer')->unsigned();
            $table->foreign('bought_by_customer')->references('id')->on('users');
            $table->integer('company_product')->unsigned();
            $table->foreign('company_product')->references('id')->on('companies');
            $table->integer('myli_store')->unsigned();
            $table->foreign('myli_store')->references('id')->on('myli_store');
            $table->integer('product_category')->unsigned();
            $table->foreign('product_category')->references('id')->on('categories');
            $table->integer('product_image')->unsigned();
            $table->foreign('product_image')->references('id')->on('images');
            $table->integer('product_video')->unsigned();
            $table->foreign('product_video')->references('id')->on('videos');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_stock');
    }
}
