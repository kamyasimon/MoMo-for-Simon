<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMyliStoreTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('myli_store', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('store_name');
            $table->string('unique_id')->unique();
            $table->string('location');
            
            $table->timestamps();


            ///FOREIGN KEYS /////
           // $table->integer('company_product')->unsigned();
           // $table->foreign('company_product')->references('id')->on('companies');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('myli_store');
    }
}
